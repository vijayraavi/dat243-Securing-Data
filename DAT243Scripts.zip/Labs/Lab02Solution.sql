USE [AdventureWorks2012]
GO
CREATE USER [SalesSupport] FOR LOGIN [SalesSupport]
GO

USE [AdventureWorks2012]
GO
CREATE USER [ITSupport] FOR LOGIN [ITSupport] WITH DEFAULT_SCHEMA=[dbo]
GO
