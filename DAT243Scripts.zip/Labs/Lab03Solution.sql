--Create a Server Audit

USE [master]
GO

-- Create Audit and enable it

CREATE SERVER AUDIT [activity_audit]
TO APPLICATION_LOG
WITH
(	QUEUE_DELAY = 1000
	,ON_FAILURE = CONTINUE
)

ALTER SERVER AUDIT [activity_audit] WITH (STATE = ON)

GO

--Create Server Audit Specification

CREATE SERVER AUDIT SPECIFICATION [audit_logins]
FOR SERVER AUDIT [activity_audit]
ADD (SUCCESSFUL_LOGIN_GROUP)
WITH (STATE = ON)

GO

--Create Database Audit Specification

USE [AdventureWorks2012]

GO

CREATE DATABASE AUDIT SPECIFICATION [product_change_audit]
FOR SERVER AUDIT [activity_audit]
ADD (INSERT ON OBJECT::[Production].[Product] BY [public]),
ADD (UPDATE ON OBJECT::[Production].[Product] BY [public])
WITH (STATE=ON)

GO

--Create some audit events

INSERT INTO [Production].[Product]
           ([Name]
           ,[ProductNumber]
           ,[MakeFlag]
           ,[FinishedGoodsFlag]
           ,[SafetyStockLevel]
           ,[ReorderPoint]
           ,[StandardCost]
           ,[ListPrice]
           ,[DaysToManufacture]
           ,[SellStartDate]
           ,[rowguid]
           ,[ModifiedDate])
     VALUES
           (LEFT(NEWID(),10)
           ,LEFT(NEWID(),10)
           ,0
           ,1
           ,99
           ,50
           ,99.99
           ,149.99
           ,14
           ,GETDATE()
           ,NEWID()
           ,GETDATE()
                        );

DECLARE @ProductID int;
SET @ProductID = SCOPE_IDENTITY();

UPDATE [Production].[Product]
   SET [Name] = LEFT(NEWID(),10)
WHERE [ProductID]=@ProductID;

GO
